/*[PATH @digikala/supernova-digikala-mobile/assets/local/js/controllers/indexController/indexAction.js]*/
IndexAction = {

    init: function () {
        var functions = [
            this.initIncredableOffer,
            this.initHeadSlider,
            this.initShowMore,
        ];

        if (isModuleActive('dk_ask_to_login_tooltip')) {
            this.initAskUserToLoginBox();
        }

        if (isModuleActive('DK_Recommendation')) {
            functions.push(this.initDKRecommendations);
        }

        if(isModuleActive('data_layer_carousels')) {
            functions.push(this.setGACarouselsImpressionEvent);
        }

        if (isModuleActive('dk_banner_view_impression_event')) {
            functions.push(this.setBannerViewImpressionEvent);
        }

        Services.callListInTryCatch(functions, this);
    },


    initAskUserToLoginBox: function () {
        var box = $('.js-ask-to-login-box');
        if(window.userId){
            box.addClass('u-hidden');
        } else {
            box.removeClass('u-hidden');
        }
    },

    initDKRecommendations: function () {
        var template = $('#product-template').clone()[0].innerHTML;
        var thiz = this;
        return;
        Services.ajaxGETRequestJSON(
            '/recommendation/v1/',
            {},
            function (response) {
                $.map(response, function (item) {
                    var products = '';
                    var dom = $('#recommendation-' + item.id);

                    if (dom.length > 0) {
                        dom.find('.o-section__headline').html(item.title)
                        $.map(item.products, function (product) {
                            if (product.image) {
                                products += thiz.createTemplate(template, {
                                    id: product.id,
                                    image: product.image,
                                    title: (product.title.length > 40 ? (product.title.substr(0, 40) + '...') : product.title),
                                    url: product.url,
                                    discount: Services.convertToFaDigit(product.price.discount_percent),
                                    isFMCG: (product.fast_shopping_badge ? 'c-product-box--fmcg' : ''),
                                    hasDiscount: (product.price.discount_percent > 0 ? '' : 'u-hidden'),
                                    price: Services.convertToFaDigit(Services.formatCurrency(product.price.selling_price, true, '')),
                                    oldValue: Services.convertToFaDigit(Services.formatCurrency(product.price.rrp_price, true, '')),
                                });
                            }
                        });
                        dom.find('.js-products-container').html(products);
                        $.map(dom.find('.js-img'), function (item) {
                            $(item).attr('src', $(item).data('img'));
                        });
                        dom.removeClass('u-hidden');
                    }
                    try {
                        if (item.data_layer) {
                            var dimension19Content = item.id === 'personal' ? 'instant-offer' : 'recommendation-' + item.id,
                                modifiedDataLayerEvent =  IndexAction.replaceGaImpressionDimension19(item.data_layer, dimension19Content);

                            window.Main.setImpressionEventOnAjax(modifiedDataLayerEvent);
                        }

                        var carouselDataTemp = {
                            'id': 'recommendation-'+item.id,
                            'carouselPosition': 'sn-'+item.id,
                            'title': item.title,
                            'title_en': 'SN '+item.id,
                            'products': item.products_tracker
                        };
                        window.carouselData.push(carouselDataTemp);
                    } catch (e) {
                    }
                });
            },
            function (response) {
            },
            false,
            false
        );
    },

    replaceGaImpressionDimension19: function (dataLayerString, replacingString) {
        return dataLayerString.replace(
            /"dimension19":"carousel-recommendation"/g,
            '"dimension19":"' + replacingString + '"'
        )
    },

    initIncredableOffer: function () {
        $('#amazingoffer .slides a').each(function () {
            var that = $(this).children('.timer');
            that.countdown({
                image: digitsImgUrl,
                format: 'hh:mm:ss',
                digitWidth: 25,
                digitHeight: 36,
                startTime: that.attr('data-et'), //'02:00:00'
            });
        });

        var $user = new UserClass();
        if (!$user.isLogged()) {
            $('.btn-light--sign-up').click(function () {
                $user.showLoginForm();
            });
        }
    },

    seedSinglePromoBoxSwiper: function (data) {

        var template =
            '<a class="swiper-slide" href="/product/dkp-{id}/" title="{title}">' +
            '<span class="c-promo-single__img" style="background-image: url({image})" > ' +
            '<img src="{image}" alt="{title}">' +
            '</span>' +
            '<span class="c-promo-single__desc">' +
            '<span class="c-promo-single__title">{title}</span>' +
            '<span class="c-promo-single__price">{price} تومان</span>' +
            '</span>' +
            '</a>';
        var items = '';

        $.each(data, $.proxy(function (index, item) {
            items += this.createTemplate(template, {
                title: item.title,
                image: item.image.replace('/120/', '/220/'),
                price: Emarsys.convertToFaDigit(Emarsys.formatCurrency(String(item.price), false, '')),
                id: item.id
            });
        }, this));

        $('.js-promo-single-loader').fadeOut(500, $.proxy(function () {
            $('.js-promo-single-wrapper').html(items);
            this.initSinglePromoBoxSwiper();
        }, this));

    },

    createTemplate: function (s, d) {
        for (var p in d)
            s = s.replace(new RegExp('{' + p + '}', 'g'), d[p]);
        return s;
    },

    initSinglePromoBoxSwiper: function () {

        window.swipers = [];

        $('.js-promo-single').each(function (i) {

            var $this = $(this),
                $promoBar = $this.find('.js-promo-single-bar'),
                $promoBox = $this.find('.js-promo-single-box');

            swipers[i] = new Swiper($promoBox.get(0), {
                slidesPerView: 1,
                speed: 500,
                allowTouchMove: false,
                autoplay: {
                    delay: 5000
                },
                loop: true,
                on: {
                    init: function () {
                        $promoBar.addClass('is-active');
                        this.lastSwipeTime = (new Date()).getTime();
                    },
                    slideChangeTransitionEnd: function () {
                        this.lastSwipeTime = (new Date()).getTime();
                        $promoBar.addClass('is-active');
                    },
                    slideChange: function () {
                        $promoBar.removeClass('is-active');
                    },
                    resize: function () {
                        setTimeout($.proxy(function () {
                            this.detachEvents();
                            this.attachEvents();
                            this.update();
                            this.autoplay.run();
                        }, this), 500);
                    }
                }
            });


            var $box = $('.js-promo-single-box');
            $box.on('mouseenter', function (e) {
                swipers[i].pauseTime = new Date().getTime();
                swipers[i].autoplay.stop();
                $promoBar.addClass('is-paused');
                console.log(swipers[i].autoplay.stop());
            });
            $box.on('mouseleave', function (e) {
                swipers[i].autoplay.start();
                swipers[i].pauseTime = 0;
                $promoBar.removeClass('is-paused');
            });

        });
    },

    initHeadSlider: function (numbOfBanners) {
        var self = this;
        self.slidersImpressionsData = [];
        var $w = $(window),
            $slider = $('.js-swiper-main'),
            top = $slider.offset().top,
            height = $slider.height(),
            bottom = top + height,
            slideCount = $slider.data('slide-count'),
            autoPlayConfig,
            sentBanners = [];

        if (slideCount > 1) {
            autoPlayConfig = { delay: 5000 };
        } else {
            autoPlayConfig = false;
        }

        new Swiper('.js-swiper-main', {
            slidesPerView: 1,
            spaceBetween: 20,
            allowTouchMove: true,
            loop: true,
            pagination: {
                el: '.swiper-pagination',
                type: 'bullets',
                clickable: true
            },
            autoplay: autoPlayConfig,
            on: {
                slideChange: function () {
                    var currentTop = $w.scrollTop();
                    var thisSlide = $(this.slides[this.activeIndex]);
                    var id = thisSlide.find('a').data('id');


                    if (Services.isScrolledIntoView(thisSlide) && isModuleActive('dk_banner_view_impression_event')) {
                        $(document).ready(function() { // waiting for back-end data
                            var observed = thisSlide.data('observed');
                            if (!observed) {
                                try {
                                    var bannerData = Services.retrieveProductFromDataLayer({
                                        productId: id,
                                        eventName: "eec.promoView",
                                        pathArray: ['ecommerce', 'promoView', 'promotions']
                                    });
                                    if (bannerData) {
                                        thisSlide.data('observed', 1);
                                        ga("ec:addPromo", bannerData);
                                    }
                                } catch (e) {
                                    console.log('Load Error: Slider View Impression')
                                }
                            }
                        })
                    }

                    if (id && sentBanners.indexOf(id) < 0 && ((top >= currentTop && top <= currentTop + height) || (bottom >= currentTop && bottom <= currentTop + height))) {
                        snt('dkBannerViewed', {bannerId: id, created_at: Date.now()});
                        sentBanners.push(id);
                    }

                }
            }
        });
    },

    initShowMore: function () {
        var expandableText = $('.js-expandable-text');
        var expandBtn = expandableText.siblings('.js-expand-btn');

        if (expandableText.height() > 120) {
            expandableText.parent().addClass('collapsed');
            expandBtn.removeClass('hidden');
        }

        expandBtn.on('click', function () {
            expandableText.parent().toggleClass('collapsed')
        });
    },

    setGAClickImpressionEvent: function(productId) {
        try {
            var productObject = Services.retrieveProductFromDataLayer({
                productId: productId,
                eventName: "eec.productImpression",
                pathArray: ['ecommerce','impressions']
            });

            var productData = removeListNameFromProductObject(productObject);
            var impressionObject = createImpressionObj(productData, Main.gaListName);

            window.dataLayer.push(impressionObject);
        } catch (e) {
            window.Sentry && window.Sentry.captureException(e);
            // eslint-disable-next-line no-console
            console.warn(e);
        }

        function removeListNameFromProductObject(productObject) {
            var productObjectCopy = Object.assign({}, productObject);

            delete productObjectCopy.list;

            return productObjectCopy;
        }

        function createImpressionObj(productData, listName) {
            return {
                'event': 'eec.impressionClick',
                'ecommerce': {
                    'click': {
                        'actionField': {
                            'list': listName
                        },
                        'products': [productData]
                    }
                }
            }
        }
    },

    setGACarouselsImpressionEvent: function () {
        $('.js-carousel-ga-product-box').click(function () {
            var itemId = $(this).data('id');
            IndexAction.setGAClickImpressionEvent(itemId);
        })
    },

    setBannerViewImpressionEvent: function () {
        var homePageBannersLen = $('.js-banner-impression-adro:not([data-id=""])').length;
        $(window).on('scroll', Services.throttle(function() {
            if(homePageBannersLen === 0) return;
            var homePageBanners = $('.js-banner-impression-adro');
            homePageBanners.each(function () {
                try {
                    var bannerId = $(this).data('id');
                    var observed = $(this).data('observed');
                    if(!bannerId || observed || !Services.isScrolledIntoView(this)) return;
                    var bannerData = Services.retrieveProductFromDataLayer({
                        productId: bannerId,
                        eventName: "eec.promoView",
                        pathArray: ['ecommerce','promoView','promotions']
                    });
                    if (bannerData){
                        homePageBannersLen -= 1;
                        $(this).data('observed' , 1);
                        ga("ec:addPromo", bannerData);
                    }
                } catch (e) {
                    console.log('GA Error: Home Page Banner View Impression')
                }
            })
        } , 500));
    }

};

$(function () {
    IndexAction.init();
});